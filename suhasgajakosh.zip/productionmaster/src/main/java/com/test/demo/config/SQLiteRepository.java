package com.test.demo.config;

import java.sql.*;

import com.test.demo.entity.ProductionOrderMasterTable;

public class SQLiteRepository {
    private Connection connection;

    public SQLiteRepository(String databasePath) {
        try {
            // Load the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");
            // Create a connection to the database
            connection = DriverManager.getConnection("jdbc:sqlite:mydb.db");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public void createTable() {
        String query = "CREATE TABLE Production_Order_Master_Table (OrderID VARCHAR(255), OrderDescription VARCHAR(255), ProductID VARCHAR(255), ProductDescription VARCHAR(255), OrderQty int, PRIMARY KEY (OrderID));";
        try (Statement statement = connection.createStatement()) {
            statement.execute(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void insertResource(ProductionOrderMasterTable productionOrderMasterTable) {
        String query = "INSERT INTO Production_Order_Master_Table (OrderID, OrderDescription, ProductID, ProductDescription, OrderQty, Plant) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, productionOrderMasterTable.getOrderID());
            preparedStatement.setString(2, productionOrderMasterTable.getOrderDescription());
            preparedStatement.setString(3, productionOrderMasterTable.getProductID());
            preparedStatement.setString(4, productionOrderMasterTable.getProductDescription());
            preparedStatement.setInt(5, productionOrderMasterTable.getOrderQty());
            preparedStatement.setString(6, productionOrderMasterTable.getPlant());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
        	System.out.println(" error occured : " + e.getStackTrace());
        }
    }

    public ResultSet getAllResources() {
        String query = "SELECT * FROM ProductionOrderMasterTable";
        try {
            Statement statement = connection.createStatement();
            return statement.executeQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public ResultSet getResourceById(String id) {
        String query = "SELECT * FROM ProductionOrderMasterTable WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, id);
            return preparedStatement.executeQuery();
        } catch (SQLException e) {
        	System.out.println(" error occured : " + e.getStackTrace());
        }
        return null;
    }

    public void updateResource(String id, ProductionOrderMasterTable productionOrderMasterTable) {
        String query = "UPDATE ProductionOrderMasterTable SET OrderDescription = ?, OrderDescription = ?, ProductID = ?, ProductDescription = ?, OrderQty = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, productionOrderMasterTable.getOrderDescription());
            preparedStatement.setString(2, productionOrderMasterTable.getProductID());
            preparedStatement.setString(3, productionOrderMasterTable.getProductDescription());
            preparedStatement.setInt(4, productionOrderMasterTable.getOrderQty());
            preparedStatement.setString(5, productionOrderMasterTable.getPlant());
            preparedStatement.setString(6, productionOrderMasterTable.getOrderID());
            preparedStatement.executeUpdate();
       
        } catch (SQLException e) {
        	System.out.println(" error occured : " + e.getStackTrace());
        }
    }

    public void deleteResource(int id) {
        String query = "DELETE FROM resources WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
        	System.out.println(" error occured : " + e.getStackTrace());
        }
    }

    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
        	System.out.println(" error occured : " + e.getStackTrace());
        }
    }
}
