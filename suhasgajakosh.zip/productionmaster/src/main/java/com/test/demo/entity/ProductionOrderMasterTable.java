package com.test.demo.entity;

import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.Table;

@Entity
@Table(name = "ProductionOrderMaster")
@IdClass(CompositeKey.class)
public class ProductionOrderMasterTable {

	@Id
	private String orderID;
	
	@Id
	private String plant;
	
	private String orderDescription;
	private String productID;
	private String productDescription;
	private int orderQty;

	public String getOrderDescription() {
		return orderDescription;
	}

	public void setOrderDescription(String orderDescription) {
		this.orderDescription = orderDescription;
	}

	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public int getOrderQty() {
		return orderQty;
	}

	public void setOrderQty(int orderQty) {
		this.orderQty = orderQty;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getPlant() {
		return plant;
	}

	public void setPlant(String plant) {
		this.plant = plant;
	}

	@Override
	public int hashCode() {
		return Objects.hash(orderDescription, orderID, orderQty, plant, productDescription, productID);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductionOrderMasterTable other = (ProductionOrderMasterTable) obj;
		return Objects.equals(orderDescription, other.orderDescription) && Objects.equals(orderID, other.orderID)
				&& orderQty == other.orderQty && Objects.equals(plant, other.plant)
				&& Objects.equals(productDescription, other.productDescription)
				&& Objects.equals(productID, other.productID);
	}

	@Override
	public String toString() {
		return "ProductionOrderMaster [orderID=" + orderID + ", plant=" + plant + ", orderDescription="
				+ orderDescription + ", productID=" + productID + ", productDescription=" + productDescription
				+ ", orderQty=" + orderQty + "]";
	}

		
	
	
}