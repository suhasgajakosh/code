package com.test.demo.service;

import java.sql.ResultSet;

import org.springframework.beans.factory.annotation.Autowired;

import com.test.demo.config.SQLiteRepository;
import com.test.demo.entity.ProductionOrderMasterTable;

public class ProductionOrderMasterServiceImpl implements ProductionOrderMasterService {

	@Autowired
	private SQLiteRepository sqLiteRepository;
	
	@Override
	public ProductionOrderMasterTable createResource(ProductionOrderMasterTable productionOrderMasterTable) {

		
		ResultSet resultSet =  sqLiteRepository.createTable();;
		if (resultSet != null) {
            try {
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String name = resultSet.getString("name");
                    String description = resultSet.getString("description");
                    Resource resource = new Resource(id, name, description);
                    resources.add(resource);
                }
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return resources;
	}

}
