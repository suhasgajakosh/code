package com.test.demo.service;

import com.test.demo.entity.ProductionOrderMasterTable;

public interface ProductionOrderMasterService {
	
	public ProductionOrderMasterTable createResource(ProductionOrderMasterTable productionOrderMasterTable);
		

}
