package com.test.demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.test.demo.entity.ProductionOrderMasterTable;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ProductionOrderMasterController {

	private List<ProductionOrderMasterTable> resources = new ArrayList<>();

    // Create a new resource
    @PostMapping(value="/create")
    public ResponseEntity<ProductionOrderMasterTable> createResource(@RequestBody ProductionOrderMasterTable resource) {
    	
    	
        resources.add(resource);
        return new ResponseEntity<>(resource, HttpStatus.CREATED);
    }
    
    // Create a mass resource
    @PostMapping(value="/createMass")
    public ResponseEntity<List<ProductionOrderMasterTable>> createMassResource(@RequestBody List<ProductionOrderMasterTable> resources) {
    	
    	
        resources.addAll(resources);
        return new ResponseEntity<>(resources, HttpStatus.CREATED);
    }

   

    // Read all resources
    @GetMapping
    public ResponseEntity<List<ProductionOrderMasterTable>> getAllResources() {
        return new ResponseEntity<>(resources, HttpStatus.OK);
    }

    // Update a resource
    @PutMapping("/{id}")
    public ResponseEntity<ProductionOrderMasterTable> updateResource(@PathVariable("id") int id, @RequestBody ProductionOrderMasterTable updatedResource) {
        	ProductionOrderMasterTable resource = resources.get(id);
        	resource.setOrderID(updatedResource.getOrderID());
        	resource.setOrderDescription(updatedResource.getOrderDescription());
        	resource.setPlant(updatedResource.getPlant());
        	resource.setOrderQty(updatedResource.getOrderQty());
        	resource.setProductDescription(updatedResource.getProductDescription());
        	resource.setProductID(updatedResource.getProductID());
            return new ResponseEntity<>(resource, HttpStatus.OK);
       
    }

    // Delete a resource
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteResource(@PathVariable("id") String id) {
            resources.remove(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        
    }
}
