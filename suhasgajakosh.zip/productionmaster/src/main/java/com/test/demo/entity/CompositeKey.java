package com.test.demo.entity;

import java.util.Objects;

public class CompositeKey {

	private Integer orderID;
	
	private String plant;

	public CompositeKey(Integer orderID, String plant) {
		super();
		this.orderID = orderID;
		this.plant = plant;
	}

	@Override
	public int hashCode() {
		return Objects.hash(orderID, plant);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CompositeKey other = (CompositeKey) obj;
		return Objects.equals(orderID, other.orderID) && Objects.equals(plant, other.plant);
	}

	@Override
	public String toString() {
		return "CompositeKey [orderID=" + orderID + ", plant=" + plant + "]";
	}
	
	
	
	
}
